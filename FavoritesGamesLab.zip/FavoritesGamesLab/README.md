# My Favorite Games

UIKit lab project that displays 20 favorite games in a `UITableView` with a custom reusable cell.

## Features

- 20 games with individual images, genres and ratings
- Custom `UITableViewCell` designed in `Main.storyboard`
- Five SF Symbol stars for every rating
- Genre sections
- Search by game title
- Add a game using the `+` button
- Delete a game with a swipe
- Adaptive Auto Layout for small and large iPhones

## Screenshots

| iPhone SE (3rd generation) | iPhone 16 Pro Max |
| --- | --- |
| ![iPhone SE preview](Screenshots/iPhone-SE.png) | ![iPhone 16 Pro Max preview](Screenshots/iPhone-16-Pro-Max.png) |

> These are layout previews. Before submission, run the project in Xcode and replace them with screenshots from the two required simulators.

## Run the project

1. Open `FavoritesGamesLab.xcodeproj` in Xcode.
2. Select an iPhone simulator.
3. Press `Command + R`.

No packages or additional setup are needed.

## Main files

- `Game.swift` - the `Game` model and the initial list of 20 games
- `GameCell.swift` - outlets and the method that fills one reusable cell
- `ViewController.swift` - table data source, sections, search, adding and deletion
- `Main.storyboard` - table view, prototype cell, stack views and all layout constraints
- `Assets.xcassets` - one image for every initial game

## How the table works

The table does not create one permanent cell for every game. It creates enough cells for the visible screen and reuses them during scrolling. `dequeueReusableCell(withIdentifier:for:)` gets a reusable cell, and `configure(with:)` fully updates its image, labels and stars.

## Defense summary

The screen uses a table view pinned to the Safe Area. Its prototype cell has the custom class `GameCell` and reuse identifier `GameCell`. The image is fixed at 82 by 82 points. Stack views place the image on the left and the title, genre and rating on the right. The controller implements `UITableViewDataSource`, groups games into genre sections, filters them with `UISearchController`, adds games through an alert and deletes them with `commit editingStyle`.
