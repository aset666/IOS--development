import UIKit

final class GameCell: UITableViewCell {
    @IBOutlet private weak var gameImageView: UIImageView!
    @IBOutlet private weak var gameTitleLabel: UILabel!
    @IBOutlet private weak var genreLabel: UILabel!
    @IBOutlet private weak var starOneImageView: UIImageView!
    @IBOutlet private weak var starTwoImageView: UIImageView!
    @IBOutlet private weak var starThreeImageView: UIImageView!
    @IBOutlet private weak var starFourImageView: UIImageView!
    @IBOutlet private weak var starFiveImageView: UIImageView!

    func configure(with game: Game) {
        gameTitleLabel.text = game.title
        genreLabel.text = game.genre
        gameImageView.image = UIImage(named: game.imageName) ?? UIImage(systemName: "gamecontroller.fill")

        let stars = [
            starOneImageView,
            starTwoImageView,
            starThreeImageView,
            starFourImageView,
            starFiveImageView
        ]

        for (index, star) in stars.enumerated() {
            let symbol = index < game.rating ? "star.fill" : "star"
            star?.image = UIImage(systemName: symbol)
        }
    }
}
