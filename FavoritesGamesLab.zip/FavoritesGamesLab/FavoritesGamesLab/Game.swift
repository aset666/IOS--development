import Foundation

struct Game {
    let id = UUID()
    let title: String
    let genre: String
    let imageName: String
    let rating: Int
}

enum GameLibrary {
    static let games: [Game] = [
        Game(title: "Counter-Strike 2", genre: "Shooter", imageName: "cs2", rating: 5),
        Game(title: "Dota 2", genre: "MOBA", imageName: "dota2", rating: 4),
        Game(title: "Warcraft III: The Frozen Throne", genre: "Strategy", imageName: "warcraft3", rating: 5),
        Game(title: "Apex Legends", genre: "Battle Royale", imageName: "apex", rating: 4),
        Game(title: "Call of Duty 4: Modern Warfare", genre: "Shooter", imageName: "cod4", rating: 5),
        Game(title: "Tom Clancy's Rainbow Six Siege", genre: "Tactical Shooter", imageName: "rainbow6", rating: 4),
        Game(title: "Elden Ring", genre: "Action RPG", imageName: "eldenRing", rating: 4),
        Game(title: "Half-Life 2", genre: "Shooter", imageName: "halfLife2", rating: 4),
        Game(title: "Grand Theft Auto V", genre: "Action", imageName: "gta5", rating: 4),
        Game(title: "Metro Exodus", genre: "Shooter", imageName: "metroExodus", rating: 5),
        Game(title: "Far Cry 3", genre: "Action Shooter", imageName: "farCry3", rating: 5),
        Game(title: "The Witcher 3: Wild Hunt", genre: "Action RPG", imageName: "witcher3", rating: 4),
        Game(title: "God of War", genre: "Action Adventure", imageName: "godOfWar", rating: 4),
        Game(title: "Red Dead Redemption 2", genre: "Action Adventure", imageName: "rdr2", rating: 4),
        Game(title: "Crysis 3", genre: "Shooter", imageName: "crysis3", rating: 5),
        Game(title: "The Elder Scrolls V: Skyrim", genre: "Action RPG", imageName: "skyrim", rating: 4),
        Game(title: "Resident Evil 4", genre: "Survival Horror", imageName: "residentEvil4", rating: 4),
        Game(title: "S.T.A.L.K.E.R. 2", genre: "Survival Shooter", imageName: "stalker2", rating: 4),
        Game(title: "Left 4 Dead 2", genre: "Survival Shooter", imageName: "left4Dead2", rating: 4),
        Game(title: "Assassin's Creed IV: Black Flag", genre: "Action Adventure", imageName: "blackFlag", rating: 4)
    ]
}
