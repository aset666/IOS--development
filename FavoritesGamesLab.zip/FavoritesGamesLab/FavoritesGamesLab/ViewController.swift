import UIKit

final class ViewController: UIViewController {
    @IBOutlet private weak var tableView: UITableView!

    private var games = GameLibrary.games
    private var sections: [(genre: String, games: [Game])] = []
    private let searchController = UISearchController(searchResultsController: nil)

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "My Favorite Games"
        configureSearch()
        rebuildSections()
    }

    private func configureSearch() {
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search games"
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        definesPresentationContext = true
    }

    private func rebuildSections() {
        let query = searchController.searchBar.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let visibleGames: [Game]

        if query.isEmpty {
            visibleGames = games
        } else {
            visibleGames = games.filter {
                $0.title.localizedCaseInsensitiveContains(query)
            }
        }

        let groupedGames = Dictionary(grouping: visibleGames, by: { $0.genre })
        sections = groupedGames.keys.sorted().map { genre in
            (genre: genre, games: groupedGames[genre] ?? [])
        }
        tableView.reloadData()
    }

    @IBAction private func addGameTapped(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "Add Game", message: "Enter the game information", preferredStyle: .alert)

        alert.addTextField { textField in
            textField.placeholder = "Game name"
            textField.autocapitalizationType = .words
        }
        alert.addTextField { textField in
            textField.placeholder = "Genre"
            textField.autocapitalizationType = .words
        }
        alert.addTextField { textField in
            textField.placeholder = "Rating (0-5)"
            textField.keyboardType = .numberPad
        }

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Add", style: .default) { [weak self, weak alert] _ in
            guard let self, let fields = alert?.textFields else { return }
            let name = fields[0].text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let genre = fields[1].text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let ratingText = fields[2].text ?? ""

            guard !name.isEmpty, !genre.isEmpty,
                  let rating = Int(ratingText), (0...5).contains(rating) else {
                self.showInputError()
                return
            }

            self.games.append(Game(title: name, genre: genre, imageName: "defaultGame", rating: rating))
            self.rebuildSections()
        })

        present(alert, animated: true)
    }

    private func showInputError() {
        let alert = UIAlertController(
            title: "Invalid Information",
            message: "Enter a name, a genre and a rating from 0 to 5.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

extension ViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        sections.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        sections[section].games.count
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        sections[section].genre
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GameCell", for: indexPath)

        guard let gameCell = cell as? GameCell else {
            return cell
        }

        let game = sections[indexPath.section].games[indexPath.row]
        gameCell.configure(with: game)
        return gameCell
    }

    func tableView(
        _ tableView: UITableView,
        commit editingStyle: UITableViewCell.EditingStyle,
        forRowAt indexPath: IndexPath
    ) {
        guard editingStyle == .delete else { return }
        let gameToDelete = sections[indexPath.section].games[indexPath.row]
        games.removeAll { $0.id == gameToDelete.id }
        rebuildSections()
    }
}

extension ViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        rebuildSections()
    }
}
