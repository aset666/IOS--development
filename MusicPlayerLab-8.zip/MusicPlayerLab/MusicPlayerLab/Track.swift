import Foundation

struct Track {
    let title: String
    let artist: String
    let fileName: String
    let fileExtension: String
    let coverImageName: String
}

enum TrackLibrary {
    static let tracks: [Track] = [
        Track(title: "Aurora", artist: "KBTU Sound Lab", fileName: "track01", fileExtension: "m4a", coverImageName: "cover01"),
        Track(title: "Blue Horizon", artist: "KBTU Sound Lab", fileName: "track02", fileExtension: "m4a", coverImageName: "cover02"),
        Track(title: "City Lights", artist: "KBTU Sound Lab", fileName: "track03", fileExtension: "m4a", coverImageName: "cover03"),
        Track(title: "Digital Rain", artist: "KBTU Sound Lab", fileName: "track04", fileExtension: "m4a", coverImageName: "cover04"),
        Track(title: "First Snow", artist: "KBTU Sound Lab", fileName: "track05", fileExtension: "m4a", coverImageName: "cover05"),
        Track(title: "Golden Steppe", artist: "KBTU Sound Lab", fileName: "track06", fileExtension: "m4a", coverImageName: "cover06"),
        Track(title: "Late Night", artist: "KBTU Sound Lab", fileName: "track07", fileExtension: "m4a", coverImageName: "cover07"),
        Track(title: "Neon Dreams", artist: "KBTU Sound Lab", fileName: "track08", fileExtension: "m4a", coverImageName: "cover08"),
        Track(title: "Quiet Morning", artist: "KBTU Sound Lab", fileName: "track09", fileExtension: "m4a", coverImageName: "cover09"),
        Track(title: "Sunset Drive", artist: "KBTU Sound Lab", fileName: "track10", fileExtension: "m4a", coverImageName: "cover10")
    ]
}
