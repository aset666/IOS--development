import AVFoundation
import UIKit

final class ViewController: UIViewController {
    @IBOutlet private weak var coverImageView: UIImageView!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var artistLabel: UILabel!
    @IBOutlet private weak var playPauseButton: UIButton!

    private let tracks = TrackLibrary.tracks
    private var currentTrackIndex = 0
    private var audioPlayer: AVAudioPlayer?
    private var shouldBePlaying = false

    override func viewDidLoad() {
        super.viewDidLoad()
        configureAudioSession()
        updateInterface()
        loadCurrentTrack(autoPlay: false)
    }

    @IBAction private func previousTapped(_ sender: UIButton) {
        guard !tracks.isEmpty else { return }
        currentTrackIndex = (currentTrackIndex - 1 + tracks.count) % tracks.count
        loadCurrentTrack(autoPlay: shouldBePlaying)
    }

    @IBAction private func playPauseTapped(_ sender: UIButton) {
        guard !tracks.isEmpty else { return }

        if audioPlayer?.isPlaying == true {
            audioPlayer?.pause()
            shouldBePlaying = false
        } else {
            if audioPlayer == nil {
                loadCurrentTrack(autoPlay: true)
            } else {
                audioPlayer?.play()
                shouldBePlaying = true
            }
        }
        updatePlayPauseIcon()
    }

    @IBAction private func nextTapped(_ sender: UIButton) {
        moveToNextTrack(autoPlay: shouldBePlaying)
    }

    private func moveToNextTrack(autoPlay: Bool) {
        guard !tracks.isEmpty else { return }
        currentTrackIndex = (currentTrackIndex + 1) % tracks.count
        loadCurrentTrack(autoPlay: autoPlay)
    }

    private func loadCurrentTrack(autoPlay: Bool) {
        guard tracks.indices.contains(currentTrackIndex) else { return }
        let track = tracks[currentTrackIndex]

        updateInterface()

        guard let url = Bundle.main.url(
            forResource: track.fileName,
            withExtension: track.fileExtension
        ) else {
            audioPlayer = nil
            shouldBePlaying = false
            updatePlayPauseIcon()
            showPlaybackError("Audio file \(track.fileName).\(track.fileExtension) was not found.")
            return
        }

        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.delegate = self
            audioPlayer?.prepareToPlay()
            shouldBePlaying = autoPlay
            if autoPlay { audioPlayer?.play() }
            updatePlayPauseIcon()
        } catch {
            audioPlayer = nil
            shouldBePlaying = false
            updatePlayPauseIcon()
            showPlaybackError("This track could not be played: \(error.localizedDescription)")
        }
    }

    private func updateInterface() {
        guard tracks.indices.contains(currentTrackIndex) else { return }
        let track = tracks[currentTrackIndex]
        titleLabel.text = track.title
        artistLabel.text = track.artist
        coverImageView.image = UIImage(named: track.coverImageName)
        updatePlayPauseIcon()
    }

    private func updatePlayPauseIcon() {
        let symbolName = shouldBePlaying ? "pause.fill" : "play.fill"
        playPauseButton.setImage(UIImage(systemName: symbolName), for: .normal)
        playPauseButton.accessibilityLabel = shouldBePlaying ? "Pause" : "Play"
    }

    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Audio session error: \(error.localizedDescription)")
        }
    }

    private func showPlaybackError(_ message: String) {
        print("Playback error: \(message)")
        let alert = UIAlertController(title: "Playback Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

extension ViewController: AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        shouldBePlaying = true
        moveToNextTrack(autoPlay: true)
    }
}
