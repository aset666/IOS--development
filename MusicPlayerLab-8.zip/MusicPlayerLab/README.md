# Music Player Lab - UIKit

A single-screen UIKit music player built with `UIStackView`, Auto Layout and `AVAudioPlayer`.

## Features

- Adaptive storyboard-only layout with three nested stack views
- Square cover image on every supported screen size
- 10 original bundled audio tracks and 10 cover images
- Play, pause, previous and next controls using SF Symbols
- Wrap-around navigation (track 10 -> track 1 and track 1 -> track 10)
- Automatic transition when a track finishes
- Safe handling of missing or broken audio files

## Screenshots

| iPhone SE (3rd generation) | iPhone 16 Pro Max |
| --- | --- |
| ![iPhone SE](Screenshots/iPhone-SE.png) | ![iPhone 16 Pro Max](Screenshots/iPhone-16-Pro-Max.png) |

> The included images are layout previews prepared without macOS. Before submission, run the project in Xcode and replace them with simulator screenshots.

## How to run

1. On a Mac, install Xcode 16 or newer.
2. Open `MusicPlayerLab.xcodeproj`.
3. Select the `MusicPlayerLab` scheme and an iPhone simulator.
4. Press **Run** (`Command + R`). No packages or additional setup are required.

## Project structure

- `Main.storyboard` - all views and Auto Layout constraints
- `ViewController.swift` - playback actions and UI state
- `Track.swift` - the `Track` model and the single track library
- `Audio/` - 10 original `.m4a` files generated for this lab
- `Assets.xcassets` - 10 cover images

## Auto Layout explanation

The vertical root stack contains the cover, the labels stack and the controls stack. It is pinned 20 pt from both Safe Area sides and centered vertically. The cover has one 1:1 aspect-ratio constraint. The horizontal controls stack uses `fillEqually`, so all three buttons receive equal width. Stack views calculate the remaining frames using their `axis`, `alignment`, `distribution` and `spacing` values.

## Quick defense notes

- `@IBOutlet` connects storyboard views to Swift properties.
- `@IBAction` runs a method when a storyboard button is tapped.
- `Bundle.main.url` finds an audio resource copied into the application bundle.
- The `audioPlayer` is a controller property, so it stays alive during playback.
- Modulo (`%`) makes next/previous navigation wrap around.
- `AVAudioPlayerDelegate` reports when playback ends, then the next track starts.

## Audio license

All audio files in this repository are original synthesized tones generated specifically for this educational project. They do not contain third-party recordings and may be used royalty-free.
