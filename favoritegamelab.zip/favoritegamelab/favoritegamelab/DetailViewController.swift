//
//  DetailViewController.swift
//  favoritegamelab
//
//  Created by Student on 11.11.2026.
//


import UIKit

class DetailViewController: UIViewController {

var game: Game?

@IBOutlet weak var gameImageView: UIImageView!
@IBOutlet weak var gameTitleLabel: UILabel!
@IBOutlet weak var genreLabel: UILabel!
@IBOutlet weak var starsStackView: UIStackView!
@IBOutlet weak var gameDescriptionLabel: UILabel!

override func viewDidLoad() {
super.viewDidLoad()
showGameDetails()
}

private func showGameDetails() {
guard let game = game else {
return
}

gameImageView.image = UIImage(named: game.imageName)
gameTitleLabel.text = game.title
genreLabel.text = game.genre
gameDescriptionLabel.text = game.description

let starImages = starsStackView.arrangedSubviews.compactMap {
$0 as? UIImageView
}

for (index, imageView) in starImages.enumerated() {
let symbolName = index < game.rating ? "star.fill" : "star"
imageView.image = UIImage(systemName: symbolName)
imageView.tintColor = .systemOrange
}
}

@IBAction func watchTrailerTapped(_ sender: UIButton) {
openLink(game?.trailerURL)
}

@IBAction func buyGameTapped(_ sender: UIButton) {
openLink(game?.storeURL)
}

private func openLink(_ link: String?) {
guard
let link = link,
let url = URL(string: link)
else {
return
}

UIApplication.shared.open(url)
}
}
