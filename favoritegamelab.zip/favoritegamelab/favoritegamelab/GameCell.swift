//
//  GameCell.swift
//  favoritegamelab
//
//  Created by Student on 11.11.2026.
//



import UIKit

class GameCell: UITableViewCell {

@IBOutlet weak var gameImageView: UIImageView!
@IBOutlet weak var gameTitleLabel: UILabel!

}

