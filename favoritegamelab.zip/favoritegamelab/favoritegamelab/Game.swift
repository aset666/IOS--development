//
//  Game.swift
//  favoritegamelab
//
//  Created by Student on 11.11.2026.
//


import Foundation

struct Game {
let title: String
let genre: String
let imageName: String
let rating: Int
let description: String
let trailerURL: String
let storeURL: String
}

