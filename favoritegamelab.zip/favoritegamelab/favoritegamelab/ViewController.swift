//
//  ViewController.swift
//  favoritegamelab
//
//  Created by Student on 05.11.2026.
//


import UIKit
class ViewController: UIViewController {
@IBOutlet weak var tableView: UITableView!

private let games: [Game] = [
    Game(
        title: "Counter-Strike 2",
        genre: "Shooter",
        imageName: "counterStrike2",
        rating: 5,
        description: "Counter-Strike 2 is a competitive multiplayer shooter where two teams complete different objectives. Players must cooperate, use strategy, and manage their equipment during every round. The game is known for precise shooting mechanics and competitive matches.",
        trailerURL: "https://www.youtube.com/results?search_query=Counter-Strike+2+official+trailer",
        storeURL: "https://store.steampowered.com/app/730/CounterStrike_2/"
    ),
    Game(
        title: "Dota 2",
        genre: "MOBA",
        imageName: "dota2",
        rating: 4,
        description: "Dota 2 is a multiplayer strategy game where two teams fight to destroy the enemy Ancient. Every hero has unique abilities and a different role in the team. Good communication, tactics, and fast decisions are important for victory.",
        trailerURL: "https://www.youtube.com/results?search_query=Dota+2+official+trailer",
        storeURL: "https://store.steampowered.com/app/570/Dota_2/"
    ),
    Game(
        title: "Warcraft III: The Frozen Throne",
        genre: "Real-Time Strategy",
        imageName: "warcraft3",
        rating: 5,
        description: "Warcraft III: The Frozen Throne is a fantasy real-time strategy game. The player builds a base, controls armies, and follows a story about powerful heroes. The game combines tactical battles, resource management, and role-playing elements.",
        trailerURL: "https://www.youtube.com/results?search_query=Warcraft+III+The+Frozen+Throne+trailer",
        storeURL: "https://us.shop.battle.net/en-us/product/warcraft-iii-reforged"
    ),
    Game(
        title: "Apex Legends",
        genre: "Battle Royale",
        imageName: "apexLegends",
        rating: 4,
        description: "Apex Legends is a fast battle royale shooter with heroes called Legends. Each Legend has special abilities that help the whole squad. Players explore the map, collect equipment, and fight to become the last surviving team.",
        trailerURL: "https://www.youtube.com/results?search_query=Apex+Legends+official+trailer",
        storeURL: "https://store.steampowered.com/app/1172470/Apex_Legends/"
    ),
    Game(
        title: "Call of Duty 4: Modern Warfare",
        genre: "Shooter",
        imageName: "callOfDuty4",
        rating: 5,
        description: "Call of Duty 4: Modern Warfare is a military first-person shooter set in a modern conflict. Its campaign follows soldiers taking part in dangerous international operations. The game is remembered for cinematic missions and influential multiplayer gameplay.",
        trailerURL: "https://www.youtube.com/results?search_query=Call+of+Duty+4+Modern+Warfare+trailer",
        storeURL: "https://store.steampowered.com/app/7940/Call_of_Duty_4_Modern_Warfare_2007/"
    ),
    Game(
        title: "Tom Clancy’s Rainbow Six Siege",
        genre: "Tactical Shooter",
        imageName: "rainbowSixSiege",
        rating: 4,
        description: "Rainbow Six Siege is a tactical shooter focused on teamwork and planning. Attackers and defenders use different operators, equipment, and abilities. Destructible environments allow players to create new entrances and defensive positions.",
        trailerURL: "https://www.youtube.com/results?search_query=Rainbow+Six+Siege+official+trailer",
        storeURL: "https://store.steampowered.com/app/359550/Tom_Clancys_Rainbow_Six_Siege/"
    ),
    Game(
        title: "Elden Ring",
        genre: "Action RPG",
        imageName: "eldenRing",
        rating: 5,
        description: "Elden Ring is an action role-playing game set in a large fantasy world. Players explore dangerous regions, develop their character, and fight powerful enemies. The game offers freedom in exploration, combat style, and character development.",
        trailerURL: "https://www.youtube.com/results?search_query=Elden+Ring+official+trailer",
        storeURL: "https://store.steampowered.com/app/1245620/ELDEN_RING/"
    ),
    Game(
        title: "Half-Life 2",
        genre: "Shooter",
        imageName: "halfLife2",
        rating: 5,
        description: "Half-Life 2 is a story-driven shooter about Gordon Freeman and the resistance against the Combine. The game combines combat, exploration, physics puzzles, and environmental storytelling. Its physics system allows players to interact creatively with objects in the world.",
        trailerURL: "https://www.youtube.com/results?search_query=Half-Life+2+official+trailer",
        storeURL: "https://store.steampowered.com/app/220/HalfLife_2/"
    ),
    Game(
        title: "Grand Theft Auto V",
        genre: "Action-Adventure",
        imageName: "gta5",
        rating: 4,
        description: "Grand Theft Auto V is an open-world action game set in Los Santos. The story follows three different protagonists whose lives become connected through dangerous criminal missions. Players can explore the city, drive vehicles, complete missions, and participate in many activities.",
        trailerURL: "https://www.youtube.com/results?search_query=Grand+Theft+Auto+V+official+trailer",
        storeURL: "https://store.steampowered.com/app/271590/Grand_Theft_Auto_V_Legacy/"
    ),
    Game(
        title: "Metro Exodus",
        genre: "Post-Apocalyptic Shooter",
        imageName: "metroExodus",
        rating: 5,
        description: "Metro Exodus is a story-focused shooter set in post-apocalyptic Russia. Artyom and his companions leave the Moscow Metro and travel across the country by train. The game combines survival, exploration, stealth, and combat in atmospheric environments.",
        trailerURL: "https://www.youtube.com/results?search_query=Metro+Exodus+official+trailer",
        storeURL: "https://store.steampowered.com/app/412020/Metro_Exodus/"
    ),
    Game(
        title: "Far Cry 3",
        genre: "Open-World Shooter",
        imageName: "farCry3",
        rating: 5,
        description: "Far Cry 3 is an open-world shooter set on dangerous tropical islands. The main character must rescue his friends and survive against pirates and mercenaries. Players can explore freely, hunt animals, capture outposts, and improve their skills.",
        trailerURL: "https://www.youtube.com/results?search_query=Far+Cry+3+official+trailer",
        storeURL: "https://store.steampowered.com/app/220240/Far_Cry_3/"
    ),
    Game(
        title: "The Witcher 3: Wild Hunt",
        genre: "Action RPG",
        imageName: "witcher3",
        rating: 5,
        description: "The Witcher 3: Wild Hunt is an open-world role-playing game about the monster hunter Geralt of Rivia. Players travel through a large fantasy world, complete quests, and make important choices. These decisions can change relationships, events, and the ending of the story.",
        trailerURL: "https://www.youtube.com/results?search_query=The+Witcher+3+Wild+Hunt+official+trailer",
        storeURL: "https://store.steampowered.com/app/292030/The_Witcher_3_Wild_Hunt/"
    ),
    Game(
        title: "God of War",
        genre: "Action-Adventure",
        imageName: "godOfWar",
        rating: 5,
        description: "God of War follows Kratos and his son Atreus on a journey through the world of Norse mythology. The story focuses on their relationship while they face gods, monsters, and personal challenges. Combat combines the Leviathan Axe, hand-to-hand attacks, and different abilities.",
        trailerURL: "https://www.youtube.com/results?search_query=God+of+War+official+trailer",
        storeURL: "https://store.steampowered.com/app/1593500/God_of_War/"
    ),
    Game(
        title: "Red Dead Redemption 2",
        genre: "Open-World Adventure",
        imageName: "redDeadRedemption2",
        rating: 5,
        description: "Red Dead Redemption 2 is an open-world western about outlaw Arthur Morgan. Players travel with the Van der Linde gang while the age of the Wild West comes to an end. The world includes story missions, hunting, exploration, conversations, and many optional activities.",
        trailerURL: "https://www.youtube.com/results?search_query=Red+Dead+Redemption+2+official+trailer",
        storeURL: "https://store.steampowered.com/app/1174180/Red_Dead_Redemption_2/"
    ),
    Game(
        title: "Crysis 3",
        genre: "Science-Fiction Shooter",
        imageName: "crysis3",
        rating: 5,
        description: "Crysis 3 is a science-fiction shooter set in a ruined future New York. The player uses a powerful Nanosuit that provides strength, armor, speed, and invisibility. Combat allows players to combine advanced weapons, stealth, and different tactical approaches.",
        trailerURL: "https://www.youtube.com/results?search_query=Crysis+3+official+trailer",
        storeURL: "https://store.steampowered.com/app/1282690/Crysis_3/"
    ),
    Game(
        title: "The Elder Scrolls V: Skyrim",
        genre: "Open-World RPG",
        imageName: "skyrim",
        rating: 5,
        description: "Skyrim is an open-world fantasy role-playing game set in the northern province of Tamriel. The player becomes the Dragonborn and learns to use powerful dragon shouts. The world contains cities, dungeons, factions, quests, and many different character builds.",
        trailerURL: "https://www.youtube.com/results?search_query=Skyrim+official+trailer",
        storeURL: "https://store.steampowered.com/app/489830/The_Elder_Scrolls_V_Skyrim_Special_Edition/"
    ),
    Game(
        title: "Resident Evil 4",
        genre: "Survival Horror",
        imageName: "residentEvil4",
        rating: 4,
        description: "Resident Evil 4 is a survival horror game about agent Leon Kennedy. He travels to a remote village to rescue the kidnapped daughter of the United States president. The game combines tense exploration, resource management, puzzles, and action-focused combat.",
        trailerURL: "https://www.youtube.com/results?search_query=Resident+Evil+4+official+trailer",
        storeURL: "https://store.steampowered.com/app/2050650/Resident_Evil_4/"
    ),
    Game(
        title: "S.T.A.L.K.E.R. 2: Heart of Chornobyl",
        genre: "Survival Shooter",
        imageName: "stalker2",
        rating: 4,
        description: "S.T.A.L.K.E.R. 2 is a survival shooter set in the dangerous Chornobyl Exclusion Zone. Players explore a large world filled with anomalies, mutants, hostile groups, and valuable artifacts. Choices made during the journey influence the story and relationships with different factions.",
        trailerURL: "https://www.youtube.com/results?search_query=STALKER+2+Heart+of+Chornobyl+official+trailer",
        storeURL: "https://store.steampowered.com/app/1643320/STALKER_2_Heart_of_Chornobyl/"
    ),
    Game(
        title: "Left 4 Dead 2",
        genre: "Cooperative Shooter",
        imageName: "left4Dead2",
        rating: 4,
        description: "Left 4 Dead 2 is a cooperative shooter where four survivors fight through zombie-infested areas. Players must stay together, share supplies, and rescue teammates from special infected enemies. The AI Director changes enemy attacks and item locations to make every match different.",
        trailerURL: "https://www.youtube.com/results?search_query=Left+4+Dead+2+official+trailer",
        storeURL: "https://store.steampowered.com/app/550/Left_4_Dead_2/"
    ),
    Game(
        title: "Assassin’s Creed IV: Black Flag",
        genre: "Action-Adventure",
        imageName: "assassinsCreedBlackFlag",
        rating: 4,
        description: "Assassin’s Creed IV: Black Flag is an open-world adventure set during the Golden Age of Piracy. Players control Edward Kenway, explore Caribbean islands, and command a pirate ship. The game combines naval battles, exploration, stealth, and traditional Assassin’s Creed combat.",
        trailerURL: "https://www.youtube.com/results?search_query=Assassins+Creed+IV+Black+Flag+official+trailer",
        storeURL: "https://store.steampowered.com/app/242050/Assassins_Creed_IV_Black_Flag/"
    )
]

override func viewDidLoad() {
    super.viewDidLoad()

    tableView.dataSource = self
    tableView.delegate = self
    tableView.rowHeight = 88
}

override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    guard
        segue.identifier == "showDetail",
        let selectedIndexPath = tableView.indexPathForSelectedRow,
        let detailViewController = segue.destination as? DetailViewController
    else {
        return
    }

    detailViewController.game = games[selectedIndexPath.row]
    tableView.deselectRow(at: selectedIndexPath, animated: true)
}
}
extension ViewController: UITableViewDataSource {
func tableView(
    _ tableView: UITableView,
    numberOfRowsInSection section: Int
) -> Int {
    return games.count
}

func tableView(
    _ tableView: UITableView,
    cellForRowAt indexPath: IndexPath
) -> UITableViewCell {
    guard let cell = tableView.dequeueReusableCell(
        withIdentifier: "GameCell",
        for: indexPath
    ) as? GameCell else {
        return UITableViewCell()
    }

    let game = games[indexPath.row]

    cell.gameTitleLabel.text = game.title
    cell.gameImageView.image = UIImage(named: game.imageName)

    return cell
}
}
extension ViewController: UITableViewDelegate {
}
