import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    // The window is created automatically from Main.storyboard (see Info.plist).
    var window: UIWindow?
}
