import UIKit

/// Variant A · Profile.
/// All views and constraints live in Main.storyboard.
/// This class only fills the labels with data.
final class ViewController: UIViewController {

    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var roleLabel: UILabel!
    @IBOutlet private weak var postsCountLabel: UILabel!
    @IBOutlet private weak var followersCountLabel: UILabel!
    @IBOutlet private weak var followingCountLabel: UILabel!
    @IBOutlet private weak var aboutLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        nameLabel.text = "Aigerim Bekova"
        // Long text test: uncomment the line below.
        // nameLabel.text = "Maximilian Alexander von Habsburg"

        roleLabel.text = "iOS Developer · Almaty"
        postsCountLabel.text = "128"
        followersCountLabel.text = "4.2K"
        followingCountLabel.text = "312"
        aboutLabel.text = "Building banking apps in Swift. I like clean architecture, coffee and long walks in the mountains around Almaty."
    }
}
