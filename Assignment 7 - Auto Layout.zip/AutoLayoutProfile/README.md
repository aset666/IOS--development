# Assignment 7 - Variant A (Profile)

Open `AutoLayoutProfile.xcodeproj` in Xcode (Mac) -> pick iPhone SE (3rd generation) or iPhone 16 Pro Max -> Run.

* All views + constraints are in `AutoLayoutProfile/Main.storyboard` (no UIStackView).
* `ViewController.swift` only fills label text.
* Long text test: uncomment the second `nameLabel.text` line in `viewDidLoad`.

If Interface Builder shows orange "Frames" warnings after opening:
select the View Controller -> Editor -> Resolve Auto Layout Issues -> "Update Frames" (all views in view controller).
